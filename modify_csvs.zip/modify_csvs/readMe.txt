Read Me

* PreRequisites: numpy and pandas in your python version

__________________________________________________________________________
* How to start...

1. Thrown down a .csv file into this directory
2. Run "python main.py" in Command Prompt (or run main.bat)
3. Enter your "filename.csv" when prompted

__________________________________________________________________________

* The function "choices"...

1. Remove duplicates: Removes boxes if they are capturing the same fish
2. Remove a label: Removes a fish label from the csv
3. Filter a confidence interval: Filters an interval using detection confidence
4. Make all multi-frame tracks...: Resets the Track ID
5. Automatically process...: Resets the Track ID AND restores confidences column to 1

__________________________________________________________________________

NOTE: testCsv.csv can be deleted. It is just here so that you can test the program.
